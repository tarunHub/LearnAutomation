package example;

import com.epam.healenium.SelfHealingDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseTest {
    protected SelfHealingDriver driver;

    public void setUp() {
        WebDriver delegate = new ChromeDriver();
        driver = SelfHealingDriver.create(delegate);
    }

    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}