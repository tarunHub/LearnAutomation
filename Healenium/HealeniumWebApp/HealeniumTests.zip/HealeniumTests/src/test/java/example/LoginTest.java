package example;

import com.epam.healenium.SelfHealingDriverWait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class LoginTest extends BaseTest {

    @BeforeClass
    public void init() {
        setUp();
    }

    @Test
    public void testLoginButtonVisibility() {
        driver.get("http://healeniumdemo.com/");

        WebElement username = new SelfHealingDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOfElementLocated(By.id("user_name")));
        username.sendKeys("testuser@gmail.com");
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        Assert.assertEquals(username.isDisplayed(), true, "username is visible");

    }

    @AfterClass
    public void cleanup() {
        tearDown();
    }
}
